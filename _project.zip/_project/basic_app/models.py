from django.db import models
from django.contrib.auth.models import User

# Create your models here.


def get_image_path(instance, filename):
    return os.path.join('photos', str(instance.id), filename)

class Student(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    name = models.CharField(max_length=300)
    address = models.CharField(max_length=300)
    mobile_no = models.CharField(max_length=300)
    student_email = models.EmailField(max_length=254)
    parent_email = models.EmailField(max_length=254)
    Subject = models.CharField(max_length=254,)
    def __str__(self):
        return self.name

class Marks(models.Model):
    exam = models.CharField(max_length=300)
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    obtained_marks = models.DecimalField(decimal_places=0, max_digits=2)
    total_marks = models.DecimalField(decimal_places=0, max_digits=3)
    def __str__(self):
        return self.user.username
