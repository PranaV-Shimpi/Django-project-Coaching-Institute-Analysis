from django.shortcuts import render
from basic_app.forms import UserForm,StudentForm,MarkForm

from django.contrib.auth import authenticate,login,logout
from django.http import HttpResponseRedirect,HttpResponse
from django.urls import reverse
from django.contrib.auth.decorators import login_required
from .models import Student,Marks
from django.contrib.auth.models import User

from django.views.generic import TemplateView,CreateView

@login_required
def user_logout(request):
    logout(request)
    return HttpResponseRedirect(reverse('home'))

def register(request):
    registered = False
    if request.method == 'POST':
        user_form = UserForm(data=request.POST)
        if user_form.is_valid():
            user = user_form.save()
            user.set_password(user.password)
            user.save()
            registered = True
        else:
            print(user_form.errors)
    else:
        user_form = UserForm()
    return render(request,'registration.html',
                          {'user_form':user_form,
                           'registered':registered})



def user_login(request):
    context = {}
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(username=username,password=password)

        if user:
            if user.is_active:
                login(request,user)
                return HttpResponseRedirect(reverse('home'))
            else:
                context["error"] = "ACCOUNT NOT ACTIVE"
                return render(request,'login.html',context)
        else:
            context["error"] = "Invalid Credentials!"
            return render(request,'login.html',context)
    else:
        return render(request,'login.html',context)

def home(request):
    string = []
    registered = False
    if request.user.is_authenticated:
            if request.method == 'POST':
                if request.user.is_superuser:
                    return HttpResponseRedirect(reverse('home'))
                else:
                    student_form = StudentForm(data=request.POST)
                    if student_form.is_valid():
                        stud = student_form.save(commit=False)
                        stud.user = request.user
                        stud.save()
                    else:
                        print(student_form.errors)
            else:
                if Student.objects.filter(user_id=request.user.id).exists():
                    registered = True
                m = Marks.objects.filter(user_id=request.user.id)
                for t in m:
                    test = t.exam
                    mark = t.obtained_marks
                    print('{ y: '+str(mark)+' , label: ""'+test+'" },')
                    string.append('{ y: '+str(mark)+' , label: "'+test+'" },')
                student_form = StudentForm()
                stud_list = Student.objects.all()
                dic =  {'student_form':student_form,'stud_list':stud_list,'registered':registered,'string':string}
                return render(request,'home.html',dic)
            return render(request,'home.html',{'registered':registered})
    else:
        return render(request,'login.html')
#
# def testlist(request):
exam = ''
o_mark = ''
t_mark = ''
def test(request):
    global exam,o_mark,t_mark
    if request.user.is_authenticated:
        if request.method == 'POST':
            if request.user.is_superuser:
                mark_form = MarkForm(data=request.POST)
                if mark_form.is_valid():
                    u = mark_form.cleaned_data['user']
                    s = Student.objects.get(user=u)
                    m = s.student_email
                    exam = mark_form.cleaned_data['exam']
                    o_mark = mark_form.cleaned_data['obtained_marks']
                    t_mark = mark_form.cleaned_data['total_marks']
                    sendmail(m)
                    print('___##___')
                    mark = mark_form.save()
                    mark.save()
                else:
                    print(mark_form.errors)
            else:
                id_r = request.user.id
                mark_form = MarkForm()
                user = User.objects.get(username=request.user.username)
                mark_list = Mark.objects.filter(user_id=id_r)
                return render(request,'test.html',
                                  {'mark_form':mark_form,'mark_list':mark_list})
        else:
            id_r = request.user.id
            mark_form = MarkForm()
            user = User.objects.get(username=request.user.username)
            mark_list = Marks.objects.filter(user_id=id_r)
            return render(request,'test.html',
                              {'mark_form':mark_form,'mark_list':mark_list})
        return render(request,'test.html',locals())
    else:
        return render(request,'login.html')


def cancellings(request):
    context = {}
    if request.method == 'POST':
        id_r = request.POST.get('stud_id')
        print('__**__')
        print(id_r)
        print('__**__')
        s = Student.objects.get(id=id_r)
        u = User.objects.get(id=s.user_id)
        u.delete()
        return HttpResponseRedirect(reverse('home'))
    else:
        return HttpResponseRedirect(reverse('home'))


import smtplib

def sendmail(receiver):
    print(receiver)
    email = '23pranavshimpi@gmail.com'
    password = 'shimpi202321'

    mail = smtplib.SMTP('smtp.gmail.com',587)
    mail.ehlo()
    mail.starttls()
    mail.login(email,password)
    mail.sendmail(email,receiver,'Test Name '+exam+'\nObtained Mark '+str(o_mark)+' out of '+str(t_mark))
    mail.close()
